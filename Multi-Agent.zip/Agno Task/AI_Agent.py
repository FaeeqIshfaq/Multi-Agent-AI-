import os
import streamlit as st
from agno.agent import Agent
from agno.models.groq import Groq
from agno.tools.duckduckgo import DuckDuckGoTools
from agno.tools.yfinance import YFinanceTools
from agno.team import Team

os.environ["GROQ_API_KEY"] = "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"

# =====================
# 🎨 Page Config
# =====================
st.set_page_config(
    page_title="Tera-Agent",
    page_icon="🌍",
    layout="wide"
)

# =====================
# 🎨 Custom CSS Styling
# =====================
st.markdown("""
    <style>
    body {
        background-color: #0d1117;
        color: #e5e5e5;
        font-family: 'Segoe UI', sans-serif;
    }
    .main-title {
        text-align: center;
        color: #2c7be5;
        font-size: 2.5em;
        font-weight: bold;
        margin-bottom: 0;
    }
    .sub-title {
        text-align: center;
        color: #00c9a7;
        font-size: 1.2em;
        margin-bottom: 30px;
    }
    .agent-card {
        background: #161b22;
        border: 1px solid #2c7be5;
        border-radius: 15px;
        padding: 20px;
        text-align: center;
        transition: 0.3s;
    }
    .agent-card:hover {
        transform: translateY(-5px);
        border-color: #00c9a7;
    }
    .stButton>button {
        background: linear-gradient(90deg, #2c7be5, #00c9a7);
        color: white;
        border: none;
        padding: 0.6em 1.3em;
        border-radius: 10px;
        font-weight: 600;
        transition: 0.3s;
    }
    .stButton>button:hover {
        background: linear-gradient(90deg, #1a5bb8, #009f84);
        transform: scale(1.05);
    }
    .result-box {
        background: #1a1f2b;
        padding: 20px;
        border-radius: 15px;
        margin-top: 20px;
        border: 1px solid #2c7be5;
    }
    footer {
        text-align: center;
        font-size: 0.8em;
        color: #888;
        margin-top: 40px;
    }
    hr {
        border: 1px solid #2c7be5;
        margin: 1.5em 0;
    }
    </style>
""", unsafe_allow_html=True)

# =====================
# 🤖 Define Agents
# =====================
web_agent = Agent(
    name="Web Agent",
    role="Search the web for sustainability initiatives",
    model=Groq(id="llama-3.3-70b-versatile"),
    tools=[DuckDuckGoTools()],
    instructions="Always include sources",
    show_tool_calls=True,
    markdown=True,
)

finance_agent = Agent(
    name="Finance Agent",
    role="Get financial & ESG data",
    model=Groq(id="llama-3.3-70b-versatile"),
    tools=[YFinanceTools(stock_price=True, analyst_recommendations=True, company_info=True)],
    instructions="Use tables for clarity",
    show_tool_calls=True,
    markdown=True,
)

analysis_agent = Agent(
    name="Analysis Agent",
    role="Analyze data & find key insights",
    model=Groq(id="llama-3.3-70b-versatile"),
    instructions="Summarize findings in bullet points with insights",
    show_tool_calls=False,
    markdown=True,
)

report_agent = Agent(
    name="Report Agent",
    role="Write a structured report",
    model=Groq(id="llama-3.3-70b-versatile"),
    instructions="Generate a professional report with sections and clear formatting",
    show_tool_calls=False,
    markdown=True,
)

agent_team = Team(
    mode="coordinate",
    members=[web_agent, finance_agent, analysis_agent, report_agent],
    model=Groq(id="llama-3.3-70b-versatile"),
    success_criteria="A comprehensive sustainability + finance report with insights.",
    instructions=["Always include sources", "Use tables for clarity"],
    show_tool_calls=True,
    markdown=True,
)

# =====================
# 🌍 Layout
# =====================
st.markdown("<h1 class='main-title'>🌍 Tera-Agent</h1>", unsafe_allow_html=True)
st.markdown("<p class='sub-title'>Mission Sustainability Dashboard</p>", unsafe_allow_html=True)

# 📌 Agent Profile Cards
col1, col2, col3, col4 = st.columns(4)
with col1:
    st.markdown("<div class='agent-card'>🔎 <br><b>Web Agent</b><br><small>Find latest sustainability news</small></div>", unsafe_allow_html=True)
with col2:
    st.markdown("<div class='agent-card'>💹 <br><b>Finance Agent</b><br><small>Analyze financial & ESG data</small></div>", unsafe_allow_html=True)
with col3:
    st.markdown("<div class='agent-card'>📊 <br><b>Analysis Agent</b><br><small>Summarize insights & trends</small></div>", unsafe_allow_html=True)
with col4:
    st.markdown("<div class='agent-card'>📝 <br><b>Report Agent</b><br><small>Create professional reports</small></div>", unsafe_allow_html=True)

st.markdown("---")

# 📌 Sidebar Controls
st.sidebar.header("⚙️ Control Panel")
mode = st.sidebar.radio("Select Mode:", ["Single Agent", "Full Team"])

if mode == "Single Agent":
    agent_choice = st.sidebar.selectbox("Choose Agent:", ["Web Agent", "Finance Agent", "Analysis Agent", "Report Agent"])
    query = st.text_input("Enter your query:")

    if st.button("🚀 Run Agent"):
        if agent_choice == "Web Agent":
            response = web_agent.run(query)
        elif agent_choice == "Finance Agent":
            response = finance_agent.run(query)
        elif agent_choice == "Analysis Agent":
            response = analysis_agent.run(query)
        else:
            response = report_agent.run(query)

        with st.expander(f"🔎 Result from {agent_choice}", expanded=True):
            st.markdown(f"<div class='result-box'>{response.content}</div>", unsafe_allow_html=True)

else:
    query = st.text_input("Enter your query for the Full Team:")
    if st.button("🤝 Run Full Team"):
        response = agent_team.run(query)
        with st.expander("🤝 Combined Team Result", expanded=True):
            st.markdown(f"<div class='result-box'>{response.content}</div>", unsafe_allow_html=True)

# =====================
# 🔻 Footer
# =====================
st.markdown("<footer>🌍 Powered by Agno Agents | Professional Dashboard UI</footer>", unsafe_allow_html=True)
